<?php include 'include/a_session.php';?>
<?php include 'include/header.php';
$report=$_GET['id'];
$query = "SELECT *,disaster_report.re_id AS reuid FROM disaster_report JOIN citizen ON disaster_report.citi_id=citizen.c_id JOIN house ON disaster_report.house_id=house.h_id JOIN disaster ON disaster_report.dis_id=disaster.dis_id WHERE disaster_report.sect_id='$admin_sect' AND disaster_report.re_id='$report'";
 $foo=mysqli_query($db,$query);
 $fow=mysqli_fetch_array($foo);
?>
<div class="wrapper">
<?php include 'include/a_nav.php';?>
<?php include 'include/a_navbar.php';?>

<div class="content-wrapper">
  <section class="content-header text-center">
    <p>Citizen Check Up</p>
  </section>
  <section class="content">
    <div class="col-md-12">
      <?php
      $bcode="";
      if (isset($_POST['Approve'])) {
            $comment=mysqli_real_escape_string($db,$_POST['comment']);
            $update="UPDATE disaster_report SET status='ok',notification='unread',comment='$comment' WHERE re_id='$report'";
            $go=mysqli_query($db,$update);
            if ($go) {
               ?> 
              
                     <div class="alert alert-success strover animated bounce col-md-12" id="aji">
                      <button class="close" data-dismiss="alert"></button>
                      <center><i>Citizen is Checked Successfully !!!</i></center>
                   </div>
                      <?php
            }
          
          }    
          elseif (isset($_POST['Disapprove'])) {
           
            $comment=mysqli_real_escape_string($db,$_POST['comment']);
            $update="UPDATE disaster_report SET status='not',notification='unread',comment='$comment' WHERE re_id='$report'";
            $go=mysqli_query($db,$update);
            if ($go) {
               ?> 
              
                     <div class="alert alert-danger animated shake col-md-12" id="aji">
                      <button class="close" data-dismiss="alert"></button>
                      <center><i>Citizen is Disapproved!!!</i></center>
                   </div>
                      <?php
            }
          
          }



      ?>
      <div class="row">
        <div class="col-md-4">
          <img src="../img/<?php echo $fow['c_profile']?>" id="photo" style="width: 340px;height: 180px;">
        </div>
        <div class="col-md-4">
         
            <ul>
              <li class="font-italic"><strong>Names</strong>       :<?php echo $fow['c_name']?></li>
              <li class="font-italic"><strong>House Number</strong>        :<?php echo $fow['h_nbr']?></li>
              <li class="font-italic"><strong>Village</strong>:<?php echo $fow['h_village']?></li>
              <li class="font-italic"><strong>Cell</strong>:<?php echo $fow['h_cell']?></li>
              <li class="font-italic"><strong>Disaster Type</strong>:<?php echo $fow['dis_name']?></li>
              <li><a download="<?php echo $fow['h_file']; ?>" href="../img/<?php echo $fow['h_file']; ?>" target="_blank"><button class=" btn btn-block btn-outline-dark  dnld"><i class="fa fa-download site-nav--icon"></i> DOWNLOAD</button></a></li>
            </ul>
         
        </div>
        <div class="col-md-4">
          <img src="../img/<?php echo $fow['dis_picture']?>" id="photo" style="width: 350px;height: 180px;">
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
        <form method="post">
          <div class="row">
          
          <div class="col-md-4 offset-md-4">
            <label for="staticEmail" class="offset-4" >Comment</label>
              <div class="input-group mb-3">
                  <div class="input-group-prepend">
                     <span class="input-group-text" ><i class="fa fa-user"></i></span>
                  </div>
                 <textarea type="text" class="form-control"name="comment" placeholder="Say something...."></textarea>       
              </div>
          </div>
        </div>
          <div class="row">
          
          <div class="col-md-6">
            <button type="submit"  id="register" name="Approve" class="btn btn-dark btn-outline-dark btn-block "><i class="fas fa-thumbs-up"></i> Approve</button>
          </div>
                <!-- </div>
                <div class="form-group row"> -->      
          <div class="col-md-6">
            <button type="submit"  id="register" name="Disapprove" class="btn btn-dark btn-outline-danger btn-block " ><i class="fas fa-thumbs-down"></i> Disapprove</button>
          </div>
          </div>
        </form>
      </div>
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>

</body>
</html>