<?php
session_start();
include 'conn.php';
if (!isset($_SESSION['admin_id'])) {
	header("location:../login.php");
}

$admin_id=$_SESSION['admin_id'];

$userr= "SELECT * FROM admin WHERE adm_id='$admin_id'";
$exl= mysqli_query($db,$userr);
$erow= mysqli_fetch_array($exl);
$admin_name=$erow['ad_name'];
$admin_profile=$erow['ad_profile'];
$admin_phone=$erow['ad_phone'];
$admin_password=$erow['ad_password'];




  ?>