<?php
include 'include/session.php';

  // $userr= "SELECT *,children.id AS enfant FROM children JOIN parent ON children.paren_id= parent.id  WHERE parent.sec_id='$umu'";
  // $exl= mysqli_query($db,$userr);
  // $erow= mysqli_fetch_array($exl);
  


$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($db, $_POST["query"]);
 $query = "SELECT * FROM disaster WHERE  dis_id LIKE '%".$search."%' OR
  dis_name LIKE '%".$search."%' 
  OR  dis_date LIKE '%".$search."%' ";
}
else
{
 $query = "
  SELECT * FROM disaster
 ";
}
$result = mysqli_query($db, $query);
if(mysqli_num_rows($result) > 0)
{
  $i=1;
 ?>
  <div class="table-hover">
   <table class="table table-bordered">
    <tr class="bg-dark text-light">
      <th class="text-center">No</th>
     <th class="text-center"> Photo</th>
     <th class="text-center">Disaster Name</th>
     <th class="text-center">Date</th>
     <th class="" width="300">Delete/Update Department</th>
    </tr>
 <?php
 

 while($row = mysqli_fetch_array($result))

 {
 
  $id=$row['dis_id'];
    ?>
   <tr class="record">
    <td class="text-center"><?php echo $i;?></td>
    <td class="text-center"><img src="../img/<?php echo $row['dis_picture']?>" style="width: 250px;height: 120px;"></td>
    <td class=""><?php echo $row['dis_name'];?></td>
    <td class="text-center" width="150"><?php echo $row['dis_date'];?></td>
    <td class="text-center">
      <a href="edit_disaster.php<?php echo '?id='.$id; ?>" class="btn btn-outline-primary text-dark"><i class="fa fa-pencil-alt"></i>&nbsp;</a>

      &nbsp;<a href="#<?php echo $id?>" id="<?php echo $id?>" class="btn btn-outline-danger text-dark deletebtn" ><i class="fa fa-trash-alt"></i>&nbsp;</a>

      </td>
   </tr>
  <?php
  $i++;

 }
 
}
else
{
 $_SESSION['message']=' 
            <div class="row" style="margin-top: 3%;">
                   <div class="alert alert-danger col-md-9 offset-md-1">
                    <button class="close" data-dismiss="alert">X</button>
                    <center><i>Data not found</i></center>
                 </div>
                 </div>
                  ';
  echo $_SESSION['message'];                
}

?>

















<script type="text/javascript">
                      $(function() {
                          $(".deletebtn").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
if(confirm("Sure you want to delete this Department? There is NO undo!"))
{

 $.ajax({
   type: "GET",
   url: "delete_depart.php",
   data: info,
   success: function(){

   }
});
 $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
 .animate({ opacity: "hide" }, "slow");

}

return false;

});

});
</script>