<?php  
 include 'include/a_session.php';
 if(isset($_POST["from_date"], $_POST["to_date"], $_POST["akw"]))  
 {  
      $connect = mysqli_connect("localhost", "root", "", "disaster");  
      $output ='';  
      $query = "  
           SELECT *,disaster_report.re_id AS reuid FROM disaster_report JOIN citizen ON disaster_report.citi_id=citizen.c_id JOIN house ON disaster_report.house_id=house.h_id JOIN disaster ON disaster_report.dis_id=disaster.dis_id WHERE disaster_report.sect_id='$admin_sect' AND disaster_report.status='ok' AND disaster_report.re_date BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'
      ";  
      $result = mysqli_query($connect, $query);
      $number=mysqli_num_rows($result);

      ?> 
       <table class="table table-bordered table-striped"  id="table">
          <thead class=" bg-dark text-light">
                <tr>
                  
                     <th>No</th>
                     <th>Name</th>
                     <th>National ID</th>
                     <th>House Number</th>
                     <th>Disaster</th>
                     <th>Village</th>
                     <th>Cell</th>
                     <th>Date</th>
                  
                </tr>
                </thead>
                <tbody>
      <?php 
      if ($number>0) {
         $i=1;
        while ($row= mysqli_fetch_array($result)) {
               
               
                              ?>
                              <tr>
                                 <td><?php echo $i;?></td>
                                 <td><?php echo $row['c_name'];?></td>
                                 <td><?php echo $row['c_nationalid'];?></td>
                                 <td><?php echo $row['h_nbr'];?></td>
                                <td><?php echo $row['dis_name'];?></td> 
                                 <td><?php echo $row['h_village'];?></td>
                                 <td><?php echo $row['h_cell'];?></td>
                                 <td><?php echo $row['re_date'];?></td>
                                
                                
                              </tr>
                              <?php
                 
             $i++;
         }
       }
       elseif($number==0) 
            {  
                 ?>  
                      <tr>  
                           <td colspan="9" style="color: red;text-align: center; ">No data Found</td>  
                      </tr>  
                 <?php  
            }
       
      ?>
      </table>
      <?php        
           
}  
?>