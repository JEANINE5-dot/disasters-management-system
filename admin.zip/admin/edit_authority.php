<?php include 'include/session.php';?>
<?php include 'include/header.php';

$autho=$_GET['id'];
$cat="SELECT * FROM sector";
$cate=mysqli_query($db,$cat);

?>
<div class="wrapper">
<?php include 'include/nav.php';?>
<?php include 'include/navbar.php';?>

<div class="content-wrapper">
  <section class="content-header text-center">
    <p>Update Sector Ruler</p>
  </section>
  <section class="content">
    <div class="row" style="">
      <div class="col-md-12" id="mia">
        <div class="col-md-10 offset-md-1 text-dark"id="took" >
          <?php
          
          
          
        if(isset($_POST["register"])){ 
          
        
       
          $phone = $_POST["phone"];
          $fullname = $_POST["fullname"];
          $chef_username=$_POST["username"];
          $password = $_POST["password"];    
          $national_id = $_POST["national_id"];
          
            
              $add="UPDATE chief_sector SET ch_phone='$phone',ch_name='$fullname',ch_nationalid='$national_id',ch_username='$chef_username',ch_password='$password' WHERE sect_id='$autho'";
                $finie=mysqli_query($db,$add);
                
             
              if($finie) {
                ?> 
              
                     <div class="alert alert-success strover animated bounce col-md-12" id="aji">
                      <button class="close" data-dismiss="alert"></button>
                      <center><i>Successfully Updated!!!</i></center>
                   </div>
                      <?php
              }
            
            
            
         }
         $query = "SELECT *,chief_sector.ch_id AS chef FROM chief_sector JOIN sector ON chief_sector.sect_id= sector.sec_id WHERE chief_sector.ch_id='$autho' ";
         $foo=mysqli_query($db,$query);
         $roww=mysqli_fetch_array($foo);
         ?>
        <form method="post" action="#" id="reg_form"enctype="multipart/form-data">
                  
                  
                  <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="name">Fullname</label>
                        <!-- <div class="input-group"> -->
                        <!-- <span class="input-group-addon"><i class="fa fa-user"></i></span> -->
                        <input type="text" class="form-control" id="name" name="fullname" placeholder=" Fullname" value="<?php echo $roww['ch_name'];?>" required >
                        
                      <!-- </div> -->
                    </div>
                    <div class="form-group col-md-6">
                        <label for="username" >National ID</label>
                        <!-- <div class="input-group"> -->
                       <!--  <span class="input-group-addon"><i class="fa fa-user"></i></span> -->
                        <input type="text" class="form-control" id="national_id" name="national_id" placeholder=" ID" value="<?php echo $roww['ch_nationalid'];?>" required>
                      <!-- </div> -->
                    </div>
                  </div>
                  <div class="form-row">
                 
                  <div class="form-group col-md-4">
                      <label for="inputAddress" >Phone number</label>
                      <!-- <div class="input-group"> -->
                      <!-- <span class="input-group-addon"><i class="fa fa-lock"></i></span> -->
                      <input type="text" class="form-control" id="email" name="phone" placeholder="phone" value="<?php echo $roww['ch_phone'];?>" required>
                    <!-- </div> -->
                  </div>
                   
                 
                    <div class="form-group col-md-4">
                        <label for="email" >Username</label>
                        <!-- <div class="input-group"> -->
                        <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                        <input type="text" class="form-control" id="email" name="username" placeholder="username" value="<?php echo $roww['ch_username'];?>" required>
                    <!--   </div> -->
                    </div>
                    <div class="form-group col-md-4">
                        <label for="email" >Password</label>
                        <!-- <div class="input-group"> -->
                        <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                        <input type="text" class="form-control" id="email" name="password" placeholder="password" value="<?php echo $roww['ch_password'];?>" required>
                    <!--   </div> -->
                    </div>
                   
                   
                  </div>
                 
                 <div class="form-group row">
                  <div class="col-md-12">
                  <button type="submit" name="register" id="register" class="btn btn-outline-success btn-block"><i class="fa fa-paper-plane"></i> Update</button>
                  </div>
                  </div>
                </form>
        </div>
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>

</body>
</html>