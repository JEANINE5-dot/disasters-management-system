<style type="text/css">
  .btn-flat {
  border-radius: 0;
  -webkit-box-shadow: none;
  -moz-box-shadow: none;
  box-shadow: none;
  border-width: 1px;
}
@media screen and (min-width: 768px){
  .dropdown:hover .dropdown-menu, .btn-group:hover .dropdown-menu{
        display: block;
        background-color: white;
        color: black;
        border-bottom-style: 1px solid black;
    }
    .dropdown-menu{
        margin-top: 0;
    }
    .dropdown-toggle{
        margin-bottom: 2px;
    }
    .navbar .dropdown-toggle, .nav-tabs .dropdown-toggle{
        margin-bottom: 0;
    }
}
</style>
<header class="main-header">
    <!-- Logo -->
    <a href="dashboard.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
     <!--  <span class="logo-mini"><b>C</b>-P</span> -->
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg text-light">Rubavu District</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <?php include'modal_logout.php';?>
    <nav class="navbar " style="background-color: #434D47;color: white;">
      <!-- Sidebar toggle button-->
      <p class="">Republic Of Rwanda</p>


      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdowntoggle" data-toggle="dropdown">
              <!-- <img src="img/seal.png" class="user-image" alt="User Image"> -->
              <span class="hidden-xs"><?php echo $admin_name ?> <i class="fa fa-list"></i></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="../img/<?php echo $admin_profile?>" class="user-image" alt="User Image">

                <p class="text-dark">
                  <?php echo $admin_name ?>
                  <small>Phone <?php echo $admin_phone ?></small>
                </p>
              </li>
              <li class="card-footer" style="background-color: #6C7972;color: white;">
                <div class="row">
                <div class="col-md-1">
                  <a href="edit_admin.php" class="btn btn-light btn-flat">Update</a>
                </div>
                <div class="col-md-1 offset-md-5">
                  <a href="logout.php" class="btn btn-light btn-flat">Sign out</a>
                </div>
              </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>