<?php include 'include/session.php';?>
<?php include 'include/header.php';?>
<div class="wrapper">
<?php include 'include/nav.php';?>
<?php include 'include/navbar.php';?>
<div class="content-wrapper">
  <!-- <section class="content-header text-center">
    <p>ajika the best man ever</p>
  </section> -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <h4 class="text-center">Disaster Reported By Sector</h4>
          
       <div id="order_table">
            <table class="table table-bordered table-striped"  id="table">
              <thead class=" bg-dark text-light">
                <tr>
                  
                  <th>No</th>
                  <th>Sector Name</th>
                  <th>Authority</th>
                  <th>National ID</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                
                  <?php
                    $i=1;

                          
                           $select="SELECT *,sector.sec_id AS sec FROM sector JOIN chief_sector ON sector.sec_id= chief_sector.sect_id";
                           $query = mysqli_query($db,$select);
                           $nbr=mysqli_num_rows($query);
                          if ($nbr>0) {
                            
                          
                             while ($row= mysqli_fetch_array($query)) {
                             $id=$row['sec'];
                              ?>
                              <tr>
                                <td><?php echo $i;?></td>
                                <td><?php echo $row['sector_name'];?></td>
                                <td><?php echo $row['ch_name'];?></td>
                                <td><?php echo $row['ch_nationalid'];?></td>
                                <td><a href="see.php<?php echo '?id='.$id; ?>" class="btn btn-outline-warning text-dark"><i class="fas fa-eye"></i>&nbsp;</a></td>
                                
                                
                              </tr>
                              <?php
                              $i++;
                             
                         }
                       }
                       else{
                        ?>  
                      <tr>  
                           <td colspan="9" style="color: red;text-align: center; ">No data Found</td>  
                      </tr>  
                 <?php 
                       }
                     
                  ?>
                </tbody>
            </table>
            </div>
  
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>
     

</body>
</html>