<?php

  $db=mysqli_connect("localhost","root","","disaster");
$id=$_GET['id'];


function generateRow($db){

       
      $contents = ''; 
      $query = "  
           SELECT *,disaster_report.re_id AS reuid FROM disaster_report JOIN citizen ON disaster_report.citi_id=citizen.c_id JOIN house ON disaster_report.house_id=house.h_id JOIN disaster ON disaster_report.dis_id=disaster.dis_id WHERE disaster_report.re_id='".$_GET['id']."'
      ";  
      $result = $db->query($query);
      $number=mysqli_num_rows($result);
 
      if ($number>0) {
         
        while ($row= $result->fetch_assoc()) {
           
                
                  $contents .= '
                        <tr>
                          
                           <td>'.$row['re_id'].'</td>
                           <td>'.$row['c_name'].'</td>
                           <td>'.$row['c_nationalid'].'</td>
                           <td>'.$row['h_nbr'].'</td>
                           <td>'.$row['h_village'].'</td>
                           <td>'.$row['h_cell'].'</td>
                           <td>'.$row['re_date'].'</td>
                        </tr>
                        ';
                 
             
           
         }
       }
       elseif($number==0) 
            {  
                 $contents .=' 
                      <tr>  
                           <td colspan="9" style="color: red;text-align: center; ">No data Found</td>  
                      </tr>
                      ';  
                   
            }
       
        
      return $contents;


      } 


      require_once('tcpdf/tcpdf.php');  
    $pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
    $pdf->SetCreator(PDF_CREATOR);  
     $pdf->SetTitle('Maternite:');  
    $pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
    $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
    $pdf->SetDefaultMonospacedFont('helvetica');  
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
    $pdf->SetMargins(PDF_MARGIN_LEFT, '10', PDF_MARGIN_RIGHT);  
    $pdf->setPrintHeader(false);  
    $pdf->setPrintFooter(false);  
    $pdf->SetAutoPageBreak(TRUE, 10);  
    $pdf->SetFont('helvetica', '', 11);  
    $pdf->AddPage();  
    $content = '';  
    $content .= '
        <h2 align="center">Individual Report</h2>
        
        <table border="1" cellspacing="0" cellpadding="3">  
           <tr>  
              
                     <th>No</th>
                     <th>Name</th>
                     <th>National ID</th>
                     <th>House Number</th>
                  
                     <th>Village</th>
                     <th>Cell</th>
                     <th>Date</th>
        
           </tr>  
      ';  
    $content .= generateRow($db);  
    $content .= '</table>';  
    $pdf->writeHTML($content);  
    $pdf->Output('district.pdf', 'I');    
// }  
?>