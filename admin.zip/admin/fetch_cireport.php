<?php
include 'include/a_session.php';
  


$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($db, $_POST["query"]);
 $query = "SELECT *,disaster_report.re_id AS reuid FROM disaster_report JOIN citizen ON disaster_report.citi_id=citizen.c_id JOIN house ON disaster_report.house_id=house.h_id JOIN disaster ON disaster_report.dis_id=disaster.dis_id WHERE disaster_report.sect_id='$admin_sect' AND citizen.c_id LIKE '%".$search."%'
  OR   citizen.c_name LIKE '%".$search."%' 
  OR   disaster.dis_name LIKE '%".$search."%' 
  OR   house.h_village LIKE '%".$search."%' 
  OR   house.h_cell LIKE '%".$search."%' 
  ";
}
else
{
 $query = "
  SELECT *,disaster_report.re_id AS reuid FROM disaster_report JOIN citizen ON disaster_report.citi_id=citizen.c_id JOIN house ON disaster_report.house_id=house.h_id JOIN disaster ON disaster_report.dis_id=disaster.dis_id WHERE disaster_report.sect_id='$admin_sect'
 ";
}

$result = mysqli_query($db, $query);
if(mysqli_num_rows($result) > 0)
{
  $i=1;
 ?>
  <div class="table-hover">
   <table class="table table-bordered">
    <tr class="bg-dark text-light">
     <th>No</th>
     <th>Name</th>
     <th>National ID</th>
     <th>House Number</th>
     <th>Disaster</th>
     <th>Village</th>
     <th>Cell</th>
     <th>Status</th>
    </tr>
 <?php
 

 while($row = mysqli_fetch_array($result))
 {
  $id=$row['reuid'];
   if ($row['status']=='unread') {
     
    ?>
    <tr class="record" style="background-color: #D1FCEF">
    <td><?php echo $i;?></td>
    <td><?php echo $row['c_name'];?></td>
    <td><?php echo $row['c_nationalid'];?></td>
    <td><?php echo $row['h_nbr'];?></td>
    <td><?php echo $row['dis_name'];?></td>
    <td><?php echo $row['h_village'];?></td>
    <td><?php echo $row['h_cell'];?></td>
    
    <td class="text-center"><a href="check.php<?php echo '?id='.$id; ?>" class="btn btn-outline-primary text-dark"><i class="fa fa-pencil-alt"></i>&nbsp;</a>&nbsp;
   </tr>
  <?php
  

  }
  elseif ($row['status']=='ok') {
      ?>
      <tr class="record" >
      <td><?php echo $i;?></td>
      <td><?php echo $row['c_name'];?></td>
      <td><?php echo $row['c_nationalid'];?></td>
      <td><?php echo $row['h_nbr'];?></td>
      <td><?php echo $row['dis_name'];?></td>
      <td><?php echo $row['h_village'];?></td>
      <td><?php echo $row['h_cell'];?></td>
      
      <td class="text-center"><a href="" class="btn btn-outline-primary text-dark"><i class="fas fa-thumbs-up"></i>&nbsp;</a>&nbsp;
     </tr>
    <?php
  }
  elseif ($row['status']=='not') {
      ?>
      <tr class="record" style="background-color: #F8C4C4">
      <td><?php echo $i;?></td>
      <td><?php echo $row['c_name'];?></td>
      <td><?php echo $row['c_nationalid'];?></td>
      <td><?php echo $row['h_nbr'];?></td>
      <td><?php echo $row['dis_name'];?></td>
      <td><?php echo $row['h_village'];?></td>
      <td><?php echo $row['h_cell'];?></td>
      
      <td class="text-center"><a href="" class="btn btn-outline-primary text-dark"><i class="fas fa-thumbs-down"></i>&nbsp;</a>&nbsp;
     </tr>
    <?php
  }
  $i++;
 }
 
}
else
{
 $_SESSION['message']=' 
            <div class="row" style="margin-top: 3%;">
                   <div class="alert alert-danger col-md-9 offset-md-1">
                    <button class="close" data-dismiss="alert">X</button>
                    <center><i>Data not found</i></center>
                 </div>
                 </div>
                  ';
  echo $_SESSION['message'];                
}

?>

















<script type="text/javascript">
                      $(function() {
                          $(".deletebtn").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
if(confirm("Sure you want to delete this Child? There is NO undo!"))
{

 $.ajax({
   type: "GET",
   url: "delete_authority.php",
   data: info,
   success: function(){

   }
});
 $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
 .animate({ opacity: "hide" }, "slow");

}

return false;

});

});
</script>