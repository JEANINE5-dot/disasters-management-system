<?php

	include('include/conn.php');
	$id=$_GET['id'];
	$result="DELETE FROM chief_sector WHERE ch_id = '$id'";
	mysqli_query($db,$result);

	
?>