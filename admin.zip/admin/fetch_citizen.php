<?php
include 'include/a_session.php';

  // $userr= "SELECT *,children.id AS enfant FROM children JOIN parent ON children.paren_id= parent.id  WHERE parent.sec_id='$umu'";
  // $exl= mysqli_query($db,$userr);
  // $erow= mysqli_fetch_array($exl);
  


$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($db, $_POST["query"]);
 $query = "SELECT * FROM citizen WHERE sect_id='$admin_sect' AND c_id LIKE '%".$search."%' 
  OR   sect_id='$admin_sect' AND c_name LIKE '%".$search."%' 
  OR   sect_id='$admin_sect' AND c_phone LIKE '%".$search."%' 
  OR   sect_id='$admin_sect' AND c_username LIKE '%".$search."%' 
   
  ";
}
else
{
 $query = "
  SELECT * FROM citizen WHERE sect_id='$admin_sect'
 ";
}

$result = mysqli_query($db, $query);
if(mysqli_num_rows($result) > 0)
{
  $i=1;
 ?>
  <div class="table-hover">
   <table class="table table-bordered">
    <tr class="bg-dark text-light">
     <th>No</th>
     <th>Photo</th>
     <th>Name</th>
     <th>National ID</th>
     <th>Phone</th>
     <th>Number of houses</th>
     <th>Update & Delete</th>
    </tr>
 <?php
 

 while($row = mysqli_fetch_array($result))
 {
  $id=$row['c_id'];

  $selectm="SELECT * FROM house WHERE citi_id='$id'";
  $c= mysqli_query($db,$selectm);
  $user= mysqli_num_rows($c);
  
    ?>
    <tr class="record">
    <td><?php echo $i;?></td>
    <td class="text-center"><img src="../img/<?php echo $row['c_profile']?>" style="width: 150px;height: 80px;"></td>
    <td><?php echo $row['c_name'];?></td>
    <td><?php echo $row['c_nationalid'];?></td>
    <td><?php echo $row['c_phone'];?></td>
    <td class="text-center"><?php echo $user;?></td>
    <td class="text-center"><a href="edit_authority.php<?php echo '?id='.$id; ?>" class="btn btn-outline-primary text-dark"><i class="fa fa-pencil-alt"></i>&nbsp;</a>&nbsp;<a href="#" id="<?php echo $row['chef']; ?>" class="btn btn-outline-danger text-dark deletebtn" ><i class="fa fa-trash-alt"></i>&nbsp;</a> 
   </tr>
  <?php
  $i++;

 }
 
}
else
{
 $_SESSION['message']=' 
            <div class="row" style="margin-top: 3%;">
                   <div class="alert alert-danger col-md-9 offset-md-1">
                    <button class="close" data-dismiss="alert">X</button>
                    <center><i>Data not found</i></center>
                 </div>
                 </div>
                  ';
  echo $_SESSION['message'];                
}

?>

















<script type="text/javascript">
                      $(function() {
                          $(".deletebtn").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
if(confirm("Sure you want to delete this Child? There is NO undo!"))
{

 $.ajax({
   type: "GET",
   url: "delete_authority.php",
   data: info,
   success: function(){

   }
});
 $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
 .animate({ opacity: "hide" }, "slow");

}

return false;

});

});
</script>