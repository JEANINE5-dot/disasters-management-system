<?php  
 //filter.php  
 if(isset($_POST["from_date"], $_POST["to_date"]))  
 {  
      $connect = mysqli_connect("localhost", "root", "", "disaster");  
      $output ='';  
      $query = "  
           SELECT *,chief_sector.ch_id AS chef FROM chief_sector JOIN sector ON chief_sector.sect_id= sector.sec_id WHERE chief_sector.ch_date BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'";  
      $result = mysqli_query($connect, $query);
      $number=mysqli_num_rows($result);
      $i=1;

      ?> 
       <table class="table table-bordered table-striped"  id="table">
          <thead class=" bg-dark text-light">
                <tr>
                  
                  <th>No</th>
                  <th>Name</th>
                  <th>National ID</th>
                  <th>Phone</th>
                  <th>Sector Rule</th>
                  <th>Employee Since</th>
                  
                </tr>
                </thead>
                <tbody>
      <?php 
      if ($number>0) {
         
        while ($row= mysqli_fetch_array($result)) {
               
                              ?>
                              <tr>
                                <td><?php echo $i;?></td>
                                <td><?php echo $row['ch_name'];?></td>
                                <td><?php echo $row['ch_nationalid'];?></td>
                                <td><?php echo $row['ch_phone'];?></td>
                                <td><?php echo $row['sector_name'];?></td>
                                <td><?php echo $row['ch_date'];?></td> 
                                
                                
                              </tr>
                              <?php
                              $i++;
             
         }

       }
       elseif($number==0) 
            {  
                 ?>  
                      <tr>  
                           <td colspan="9" style="color: red;text-align: center; ">No data Found</td>  
                      </tr>  
                 <?php  
            }
       
      ?>
      </table>
      <?php        
           
}  
?>