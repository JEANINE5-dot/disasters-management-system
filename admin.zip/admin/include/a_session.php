<?php
session_start();
include 'conn.php';
if (!isset($_SESSION['chief_id'])) {
	header("location:../login.php");
}

$admin_id=$_SESSION['chief_id'];

$userr= "SELECT *,chief_sector.ch_id AS chef FROM chief_sector JOIN sector ON chief_sector.sect_id= sector.sec_id  WHERE  chief_sector.ch_id='$admin_id'";
$exl= mysqli_query($db,$userr);
$erow= mysqli_fetch_array($exl);
$admin_name=$erow['ch_name'];
$admin_profile=$erow['ch_profile'];
$admin_phone=$erow['ch_phone'];
$admin_password=$erow['ch_password'];
$admin_sect=$erow['sect_id'];




  ?>