
<?php 
include 'include/session.php';
include 'include/header.php';

 ?>
<div class="wrapper">
<?php include 'include/nav.php';?>
<?php include 'include/navbar.php';?>
<style type="text/css">
  
  }
</style>
<div class="content-wrapper">
  <section class="content-header text-center">
    <p>Rubavu District</p>
  </section>
  <section class="content">
    <div class="row" style="">
      <div class="col-md-6 offset-3" id="took">
           <img src="../images/wseal.jpg" style="width: 500px;height: 300px">
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>
</body>
</html>