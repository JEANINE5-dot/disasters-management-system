<?php include 'include/session.php';?>
<?php include 'include/header.php';?>
<div class="wrapper">
<?php include 'include/nav.php';?>
<?php include 'include/navbar.php';?>

<div class="content-wrapper">
  <section class="content-header text-center">
    <h2>Add New Sector</h2>
  </section>
  <section class="content">
    <div class="row" style="">
      <div class="col-md-12" id="mia">
        <div class="col-md-6 offset-md-3 text-dark"id="took">
          <?php
           $sector_name = "";
           $date_created = "";
            
          if(isset($_POST["register"])){ 
            
            $date_created = $_POST["date_created"];
            $sector_name = $_POST["sector_name"];
            
            

                    $selectm="SELECT * FROM sector WHERE sector_name='$sector_name'";
                    $c= mysqli_query($db,$selectm);
                    $user= mysqli_num_rows($c);
                    

              if($user){
                ?>
                <style type="text/css">
                  #sector_name{
                    color: #a94442;
                    background-color: #f2dede;
                    border-color: #a94442;
                  }
                </style> 
                       <div class="alert alert-danger animated shake col-md-12" id="aji">
                        <button class="close" data-dismiss="alert"></button>
                        <center><i>Sector name exist already!!!</i></center>
                     </div>
                        <?php
              }
              
              else{
                $add="INSERT INTO  sector(sector_name,date_created) VALUES ('$sector_name','$date_created')";
                  $ajika=mysqli_query($db,$add);
              if ($ajika) {
                ?> 
                       <div class="alert alert-success strover animated bounce col-md-12" id="aji">
                        <button class="close" data-dismiss="alert"></button>
                        <center><i>Successfuly Registred</i></center>
                     </div>
                        <?php
              }
              }
              
           }
       
          
        
         ?>
        <form class="form-horizontal" method="POST" action="" id="reg_form"enctype="multipart/form-data">
        <div class="form-group">
           

            <div class="col-sm-12">
               <label for="employee" >Sector Name</label>
               <div class="input-group mb-3">
                <div class="input-group-prepend">
                   <span id="phone" class="input-group-text" ><i class="fa fa-user"></i></span>
                </div>
              <input type="text" class="form-control" id="dep_name" name="sector_name" value="<?php echo $sector_name;?>"required placeholder="Sector Name" >
            </div>
          </div>
        </div>
      
        <div class="form-group">
            

            <div class="col-sm-12"> 
              <label for="datepicker_add">Date</label>

              <div class="date">
                <div class="input-group mb-3">
                        <div class="input-group-prepend">
                           <span id="passworda" class="input-group-text" ><i class="fa fa-clock"></i></span>
                        </div>
                <input type="text" class="form-control" id="date" name="date_created" value="<?php echo $date_created;?>" placeholder="Date" required>
              </div>
            </div>
            </div>
        </div>
        
        
    
    <div class=" form-group col-md-12">  
      <button type="submit" class="btn  btn-block btn-outline-success" name="register"><i class="fas fa-sign-in-alt"></i> Add Sector</button>
    </div>
      </form>
    </div>
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>

</body>
</html>