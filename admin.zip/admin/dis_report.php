<?php include 'include/a_session.php';?>
<?php include 'include/header.php';?>
<div class="wrapper">
<?php include 'include/a_nav.php';?>
<?php include 'include/a_navbar.php';?>
<div class="content-wrapper">
  <!-- <section class="content-header text-center">
    <p>ajika the best man ever</p>
  </section> -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
           
  
        <div class="col-md-12">
           <div id="order_table">
           <table class="table table-bordered table-striped"  id="table">
             <thead class=" bg-dark text-light">
               <tr class="bg-dark text-light">
                     <th class="text-center">No</th>
                    <th class="text-center"> Photo</th>
                    <th class="text-center">Disaster Name</th>
                    <th class="" width="300">Report</th>
                   </tr>
               </thead>
               <tbody>
               
                 <?php
           
                   // $sel= "SELECT *,users.id_users AS patient_id FROM users JOIN detail ON users.id_users=detail.id_users WHERE detail.death = 'None'";
                   // $e= mysqli_query($db,$sel);
                   // $mai=mysqli_num_rows($e);

                          $select="SELECT * FROM disaster";
                          $query = mysqli_query($db,$select);
                          $i=1;
                            while ($row= mysqli_fetch_array($query)) {
                             $id=$row['dis_id'];
                                 ?>
                                <tr class="record">
                                 <td class="text-center"><?php echo $i;?></td>
                                 <td class="text-center"><img src="../img/<?php echo $row['dis_picture']?>" style="width: 250px;height: 120px;"></td>
                                 <td class=""><?php echo $row['dis_name'];?></td>
                              
                                 <td class="text-center">
                                   <a href="view_dis.php<?php echo '?id='.$id; ?>" class="btn btn-outline-primary text-dark"><i class="fa fa-pencil-alt"></i>&nbsp;</a>


                                   </td>
                                </tr>
                             <?php
                            $i++;
                        }
                    
                 ?>
               </tbody>
           </table>
           </div>
        </div>
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>
  <script>
     $(document).ready(function(){

      load_data();

      function load_data(query)
      {
       $.ajax({
        url:"fetch_cireport.php",
        method:"POST",
        data:{query:query},
        success:function(data)
        {
         $('#result').html(data);
        }
       });
      }
      $('#search_text').keyup(function(){
       var search = $(this).val();
       if(search != '')
       {
        load_data(search);
       }
       else
       {
        load_data();
       }
      });
     });
     </script>
</body>
</html>