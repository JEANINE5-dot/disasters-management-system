<?php include 'include/session.php';?>
<?php include 'include/header.php';?>
<div class="wrapper">
<?php include 'include/nav.php';?>
<?php include 'include/navbar.php';?>

<div class="content-wrapper">
  <section class="content-header text-center">
    <h2>Add New Disaster Type</h2>
  </section>
  <section class="content">
    <div class="row" style="">
      <div class="col-md-12" id="mia">
        <div class="col-md-6 offset-md-3 text-dark"id="took">
          <?php
         $dis_name = "";
         $date_created = "";
          
        if(isset($_POST["register"])){ 
          
          $date_created = $_POST["date_created"];
          $dis_name = $_POST["dis_name"];
          $dis_picture=$_FILES['dis_picture']['name'];
          $bphomove="../img/".$_FILES['dis_picture']['name'];
          
          $allowed_image_extension = array(
              "png",
              "jpg",
              "jpeg"
          );
          // Get image file extension
          $file_extension = pathinfo($_FILES["dis_picture"]["name"], PATHINFO_EXTENSION);

           if (!in_array($file_extension, $allowed_image_extension)) {
            ?>
             <div class="alert alert-danger animated shake col-md-12" id="aji">
               <button class="close" data-dismiss="alert"></button>
               <center><i>Only PNG and JPG are allowed!!!</i></center>
             </div>
            <?php
             
          }
          else{

          $selectm="SELECT * FROM disaster WHERE dis_name='$dis_name'";
          $c= mysqli_query($db,$selectm);
          $user= mysqli_num_rows($c);
         
                  
            if($user){
              ?>
              <style type="text/css">
                #sector_name{
                  color: #a94442;
                  background-color: #f2dede;
                  border-color: #a94442;
                }
              </style> 
              <div class="alert alert-danger animated shake col-md-12" id="aji">
                <button class="close" data-dismiss="alert"></button>
                <center><i>Disaster name exist already!!!</i></center>
             </div>
              <?php
            }
            
            else{
              $add="INSERT INTO disaster (dis_name,dis_date,dis_picture) VALUES ('$dis_name','$date_created','$dis_picture')";
                $query=mysqli_query($db,$add);
                 $a=move_uploaded_file($_FILES['dis_picture']['tmp_name'], $bphomove);
                
            if ($query AND $a) {
              ?> 
                     <div class="alert alert-success strover animated bounce col-md-12" id="aji">
                      <button class="close" data-dismiss="alert"></button>
                      <center><i>Successfuly Registred</i></center>
                   </div>
                      <?php
            }
            }
          }
            
         }
        ?>
        <form class="form-horizontal" method="POST" action="" id="reg_form"enctype="multipart/form-data">
        <div class="form-group">
           

            <div class="col-sm-12">
               <label for="employee" >Disaster Name</label>
               <div class="input-group mb-3">
                <div class="input-group-prepend">
                   <span id="phone" class="input-group-text" ><i class="fa fa-user"></i></span>
                </div>
              <input type="text" class="form-control" id="dep_name" name="dis_name" value="<?php echo $dis_name;?>"required placeholder="Disaster Name" >
            </div>
          </div>
        </div>
        <div class="form-group col-md-12">
            <label for="inputAddress" >Picture</label>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                 <span id="full" class="input-group-text"><i class="fa fa-user"></i></span>
              </div>
            <input type="file" class="form-control" id="email" name="dis_picture" required>
          <!-- </div> -->
        </div>
        </div>
        <div class="form-group">
            

            <div class="col-sm-12"> 
              <label for="datepicker_add">Date</label>

              <div class="date">
                <div class="input-group mb-3">
                        <div class="input-group-prepend">
                           <span id="passworda" class="input-group-text" ><i class="fa fa-clock"></i></span>
                        </div>
                <input type="text" class="form-control" id="date" name="date_created" value="<?php echo $date_created;?>" placeholder="Date" required>
              </div>
            </div>
            </div>
        </div>
        
        
    
    <div class=" form-group col-md-12">  
      <button type="submit" class="btn  btn-block btn-outline-success" name="register"><i class="fas fa-sign-in-alt"></i> Add Disaster</button>
    </div>
      </form>
    </div>
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>

</body>
</html>