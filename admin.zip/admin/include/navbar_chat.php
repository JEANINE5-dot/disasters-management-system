
<aside class="main-sidebar text-light" style="background-color: #305553;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
     <!--  Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left info" >
          <p><?php echo $admin_name?></p>
          <!-- <a><i class="fa fa-circle text-success"></i> Online</a> -->
        </div>
        <div class="pull-left image">
         <img src="../img/<?php echo $admin_profile;?>" class="user-image" alt="User Image"> 
        </div>
        
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" >
        
        <li class="card-header" ><div class="c">Agency Activities</div></li>

        <li class="liste"><a href="student_page.php"><i class="fa fa-inbox site-nav--icon"></i> Inbox <span><?php echo $count2; ?></span></a></li>
        <li class="liste"><<a href="sent_requests.php"><i class="fa fa-paper-plane site-nav--icon"></i> Sent</a></li>
       <!--  <li class="liste"><a href="add_destination.php"><i class="fa fa-plus"></i> <span>Destination</span> <i class="fa fa-map-marker"></i></a></li> -->
        <li class="liste"><a href="view_depart.php"><i class="fa fa-eye"></i> <span> Department</span> </a></li>
        <li class="liste"><a href="view_stu.php"><i class="fa fa-eye"></i> <span> Student</span> <i class="fa fa-map-marker"></i></a></li>
        <li class="liste"><a href="view_plane.php"><i class="fa fa-eye"></i> <span>Plane</span> <i class="fa fa-plane"></i></a></li>
        <li class="liste"><a href="view_passenger.php"><i class="fa fa-users"></i> <span> Passenger</span></a></li>
        
     
       
        
        
       
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>