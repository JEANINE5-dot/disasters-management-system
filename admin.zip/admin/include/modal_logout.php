<div class="modal fade" id="logout" aria-labelledby="myModalLabel" aria-hidden="true">
  	<div class="modal-dialog">
  		<div class="modal-content">
  			<div class="modal-header">
  				Request
  			</div>
  			<div class="modal-body bg-danger ">
  			<div class="text-center text-light">Are you Sure you want logout?</div>
  			</div>
  			<div class="modal-footer">
  				<button class="btn btn-dark" data-dismiss="modal" aria-hidden="true"><i class="fas fa-thumbs-down"></i> No</button>
  				<a href="logout.php" class="btn btn-danger"><i class="fas fa-thumbs-up"></i> Yes</a>
  			</div>
  		</div>
  	</div>
</div>