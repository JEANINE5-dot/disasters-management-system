<?php include 'include/session.php';?>
<?php include 'include/header.php';?>
<div class="wrapper">
<?php include 'include/nav.php';?>
<?php include 'include/navbar.php';?>
<div class="content-wrapper">
  <!-- <section class="content-header text-center">
    <p>ajika the best man ever</p>
  </section> -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
           <h4 class="text-center">Search Sector Chef</h4>
  
    <div class="col-md-12">
  <div class="form-group">
     <div class="input-group">
      <div class="input-group-prepend">
           <span  class="input-group-text"><i class="fa fa-search"></i></span>
          </div>
      <input type="text" name="search_text" id="search_text" placeholder="Search Sector chef" class="form-control" />
     </div>
    </div>
    <br />
    <div id="result"></div>
  </div>
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>
  <script>
     $(document).ready(function(){

      load_data();

      function load_data(query)
      {
       $.ajax({
        url:"fetch_authority.php",
        method:"POST",
        data:{query:query},
        success:function(data)
        {
         $('#result').html(data);
        }
       });
      }
      $('#search_text').keyup(function(){
       var search = $(this).val();
       if(search != '')
       {
        load_data(search);
       }
       else
       {
        load_data();
       }
      });
     });
     </script>
</body>
</html>