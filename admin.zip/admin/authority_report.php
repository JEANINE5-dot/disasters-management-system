<?php include 'include/session.php';?>
<?php include 'include/header.php';?>
<div class="wrapper">
<?php include 'include/nav.php';?>
<?php include 'include/navbar.php';?>
<div class="content-wrapper">
  <!-- <section class="content-header text-center">
    <p>ajika the best man ever</p>
  </section> -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <h4 class="text-center">Sector Authority Report</h4>
         <form method="POST" id="payForm">
                <div class="form-row">
                 <div class="col-md-2">  
                     <input type="text" name="from_date" id="from_date" class="form-control" placeholder="From Date" />  
                </div>  
                <div class="col-md-6">  
                     <input type="text" name="to_date" id="to_date" class="form-control" placeholder="To Date" />  
                     <!-- <input type="hidden" name="akw" id="akw" value="<?php echo $umudugudu;?>" class="form-control" placeholder="To Date" /> --> 
                </div>  
                <div class="col-md-2">  
                     <input type="button" class="btn btn-outline-primary btn-block" name="filter" id="filter" value="search" class="btn btn-info" />  
                </div>
                <div class="col-md-2">
                  <!-- <form id="payForm" method="POST"> -->
          <button type="button" class="btn btn-outline-success btn-block" name="payroll" id="payroll"><span class="fa fa-print"></span> Print</button>
        <!-- </form> -->
        </div> 
      </div>
        </form>  
       <div id="order_table">
            <table class="table table-bordered table-striped"  id="table">
              <thead class=" bg-dark text-light">
                <tr>
                  
                  <th>No</th>
                  <th>Name</th>
                  <th>National ID</th>
                  <th>Phone</th>
                  <th>Sector Rule</th>
                  <th>Employee Since</th>
                </tr>
                </thead>
                <tbody>
                
                  <?php
                    $i=1;

                           $select="SELECT *,chief_sector.ch_id AS chef FROM chief_sector JOIN sector ON chief_sector.sect_id= sector.sec_id";
                           $query = mysqli_query($db,$select);
                           $nbr=mysqli_num_rows($query);
                          if ($nbr>0) {
                            
                          
                             while ($row= mysqli_fetch_array($query)) {
                             
                              ?>
                              <tr>
                                <td><?php echo $i;?></td>
                                <td><?php echo $row['ch_name'];?></td>
                                <td><?php echo $row['ch_nationalid'];?></td>
                                <td><?php echo $row['ch_phone'];?></td>
                                <td><?php echo $row['sector_name'];?></td>
                                <td><?php echo $row['ch_date'];?></td>
                                
                                
                              </tr>
                              <?php
                              $i++;
                             
                         }
                       }
                       else{
                        ?>  
                      <tr>  
                           <td colspan="9" style="color: red;text-align: center; ">No data Found</td>  
                      </tr>  
                 <?php 
                       }
                     
                  ?>
                </tbody>
            </table>
            </div>
  
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>
     <script type="text/javascript">
      $(document).ready(function(){  
           $.datepicker.setDefaults({  
                dateFormat: 'yy-mm-dd',
                showAnim: 'drop'   
           });  
           $(function(){  
                $("#from_date").datepicker();  
                $("#to_date").datepicker();  
           });  
           $('#filter').click(function(){  
                var from_date = $('#from_date').val();  
                var to_date = $('#to_date').val();  
                // var akw = $('#akw').val();  
                if(from_date != '' && to_date != '')  
                {  
                     $.ajax({  
                          url:"filter_authority.php",  
                          method:"POST",  
                          data:{from_date:from_date, to_date:to_date},  
                          success:function(data)  
                          {  
                               $('#order_table').html(data);  
                          }  
                     });  
                }  
                else  
                {  
                     alert("Please Select Date");  
                }  
           });

  
      });  
    </script>
    <script>
$(function(){
  
  $('#payroll').click(function(e){
    e.preventDefault();
    $('#payForm').attr('action', 'print_authority.php');
    $('#payForm').submit();
  });

  

});




</script>
</body>
</html>