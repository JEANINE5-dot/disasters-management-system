<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>Rubavu District</title>
  <!-- the photo of IPRC in the browser -->
   <link rel="icon" href="../images/wseal.jpg" type="">
  <link rel="stylesheet" href="css/animate.css">
  <script src="js/wow.min.js"></script>
  <script>
     new WOW().init();
  </script>
  <link rel="stylesheet" href="css/animate2.css">
  <link rel="stylesheet" href="bootstrap-4.1.3-dist/css/bootstrap.css">
  <!-- <link rel="stylesheet" href="../re/css/mdb.css"> -->
  <link rel="stylesheet" type="text/css" href="bootstrap-4.1.3-dist/css/chat_bubble.css" media="all">
  <link rel="stylesheet" href="bootstrap-4.1.3-dist/css/validecss.css">
  <link rel="stylesheet" href="css/AdminLTE.css">
  
    <!-- bootstrap datepicker -->
    
  

 <!--  <link rel="stylesheet" href="_all-skins.min.css"> -->
  <body style="">
    <style type="text/css">
      /*.content-wrapper{
        background-color: rgba(0, 0, 0, 0.6) !important;
      }*/
     /* .content{
        background-image: url(../img/wseal.jpg);
      }*/
    </style>


