<?php
// $que = "SELECT * FROM texting WHERE from_message='student' AND q_status='unread'";
// $res = mysqli_query($db,$que);
// $kog=mysqli_num_rows($res);

// $quest = "SELECT * FROM student WHERE status='Seeding'";
// $resst = mysqli_query($db,$quest);
// $studd=mysqli_num_rows($resst);
?>
<aside class="main-sidebar text-light" style="background-color: #305553;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
     <!--  Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left info" >
          <p><?php echo $admin_name?></p>
          <!-- <a><i class="fa fa-circle text-success"></i> Online</a> -->
        </div>
        <div class="pull-left image">
         <img src="../img/<?php echo $admin_profile;?>" class="user-image" alt="User Image"> 
        </div>
        
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" >
        
        <li class="card-header" ><div class="c">Agency Activities</div></li>

        <li class="liste"><a href="add_sector.php"><i class="fa fa-plus"></i> <span>Add Sector</span></a></li>
        <li class="liste"><a href="add_authority.php"><i class="fa fa-plus"></i> <span>Add Sector Chief</span></a></li>
        <li class="liste"><a href="add_disaster.php"><i class="fa fa-plus"></i> <span>Add Disaster Type</span></a></li>
        <li class="liste"><a href="view_disaster.php"><i class="fa fa-plus"></i> <span>View Disaster</span></a></li>
        <li class="liste"><a href="view_authority.php"><i class="fa fa-inbox site-nav--icon"></i><span>Authority</span> </a></li>
    
      
        <li class="card-header"><div class="c">REPORTS</div></li>
        
        <li class="liste"><a href="authority_report.php"><i class="fa fa-clock"></i> <span>Authority</span></a></li>
      
        <li class="liste"><a href="sector_ind.php"><i class="fa fa-clock"></i> <span>Sector Disaster</span></a></li>
        
        
       
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>