<?php
include 'include/a_session.php';
include 'include/header.php';

$query = "SELECT *,disaster_report.re_id AS reuid FROM disaster_report JOIN citizen ON disaster_report.citi_id=citizen.c_id JOIN house ON disaster_report.house_id=house.h_id JOIN disaster ON disaster_report.dis_id=disaster.dis_id JOIN sector ON disaster_report.sect_id=sector.sec_id WHERE disaster_report.sect_id='$admin_sect' AND disaster_report.status='ok' ";
 $foo=mysqli_query($db,$query);
 $fow=mysqli_fetch_array($foo);
?>
<div class="wrapper">
<?php include 'include/a_nav.php';?>
<?php include 'include/a_navbar.php';?>

<div class="content-wrapper">
  <section class="content-header text-center">
    
  </section>
  <section class="content">
    <div class="row" style="">

<div class="col-md-12">
	  
        <div class="row">
          <div class="col-md-12">
            <h3 class="text-center">All Citizen Report</h3>
          </div>
        </div>
              <form method="POST" id="payForm">
                <div class="form-row">
                 <div class="col-md-2">  
                     <input type="text" name="from_date" id="from_date" class="form-control" placeholder="From Date" />  
                </div>  
                <div class="col-md-6">  
                     <input type="text" name="to_date" id="to_date" class="form-control" placeholder="To Date" />  
                     <input type="hidden" name="akw" id="akw" value="<?php echo $fow['sector_name'];?>" class="form-control" placeholder="To Date" /> 
                     <input type="hidden" name="aka" id="aka" value="<?php echo $admin_sect;?>" class="form-control" placeholder="To Date" /> 
                     
                </div>  
                <div class="col-md-2">  
                     <input type="button" class="btn btn-outline-primary btn-block" name="filter" id="filter" value="search" class="btn btn-info" />  
                </div>
                <div class="col-md-2">
                  <!-- <form id="payForm" method="POST"> -->
          <button type="button" class="btn btn-outline-success btn-block" name="payroll" id="payroll"><span class="fa fa-print"></span> Print</button>
        <!-- </form> -->
        </div> 
      </div>
        </form> 
                <div style="clear:both"></div>                 
                <br />
               
                
            <div id="order_table">
            <table class="table table-bordered table-striped"  id="table">
              <thead class=" bg-dark text-light">
                <tr>
                  
                <th>No</th>
                <th>Name</th>
                <th>National ID</th>
                <th>House Number</th>
                <th>Disaster</th>
                <th>Village</th>
                <th>Cell</th>
                <th>Date</th>
                  
                </tr>
                </thead>
                <tbody>
                
                  <?php
      
                   

                           $select="SELECT *,disaster_report.re_id AS reuid FROM disaster_report JOIN citizen ON disaster_report.citi_id=citizen.c_id JOIN house ON disaster_report.house_id=house.h_id JOIN disaster ON disaster_report.dis_id=disaster.dis_id WHERE disaster_report.sect_id='$admin_sect' AND disaster_report.status='ok'";
                           $query = mysqli_query($db,$select);
                           $nbr=mysqli_num_rows($query);
                           $i=1;
                          if ($nbr>0) {
                            
                          
                             while ($row= mysqli_fetch_array($query)) {
                              
                              ?>
                              <tr>
                                <td><?php echo $i;?></td>
                                <td><?php echo $row['c_name'];?></td>
                                <td><?php echo $row['c_nationalid'];?></td>
                                <td><?php echo $row['h_nbr'];?></td>
                               <td><?php echo $row['dis_name'];?></td>
                                <td><?php echo $row['h_village'];?></td>
                                <td><?php echo $row['h_cell'];?></td>
                                <td><?php echo $row['re_date'];?></td>
                                
                                
                              </tr>
                              <?php
                             $i++;
                         }
                       }
                       else{
                        ?>  
                      <tr>  
                           <td colspan="9" style="color: red;text-align: center; ">No data Found</td>  
                      </tr>  
                 <?php 
                       }
                     
                  ?>
                </tbody>
            </table>
            </div>
          </div>
          </div>
      
</div>
</div>
</div>
</div>
<?php include 'include/footer.php';?>
   <script type="text/javascript">
      $(document).ready(function(){  
           $.datepicker.setDefaults({  
                dateFormat: 'yy-mm-dd'   
           });  
           $(function(){  
                $("#from_date").datepicker();  
                $("#to_date").datepicker();  
           });  
           $('#filter').click(function(){  
                var from_date = $('#from_date').val();  
                var to_date = $('#to_date').val();  
                var akw = $('#akw').val();  
                var aka = $('#aka').val();  
                 
                if(from_date != '' && to_date != '')  
                {  
                     $.ajax({  
                          url:"filter_view_dis.php",  
                          method:"POST",  
                          data:{from_date:from_date, to_date:to_date, akw:akw,aka:aka},  
                          success:function(data)  
                          {  
                               $('#order_table').html(data);  
                          }  
                     });  
                }  
                else  
                {  
                     alert("Please Select Date");  
                }  
           });

  
      });  
    </script>
    <script>
$(function(){
  
  $('#payroll').click(function(e){
    e.preventDefault();
    $('#payForm').attr('action', 'print_sect_all.php');
    $('#payForm').submit();
  });

  

});




</script>
</body>
</html>
            