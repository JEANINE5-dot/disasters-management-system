<?php
$que = "SELECT * FROM disaster_report WHERE sect_id='$admin_sect' AND status='unread'";
$res = mysqli_query($db,$que);
$kog=mysqli_num_rows($res);
?>
<aside class="main-sidebar text-light" style="background-color: #305553;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
     <!--  Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left info" >
          <p><?php echo $admin_name?></p>
          <!-- <a><i class="fa fa-circle text-success"></i> Online</a> -->
        </div>
        <div class="pull-left image">
         <img src="../img/<?php echo $admin_profile;?>" class="user-image" alt="User Image"> 
        </div>
        
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" >
        
        <li class="card-header" ><div class="c">Agency Activities</div></li>

        <li class="liste"><a href="view_citizen.php"><i class="fa fa-plus"></i> <span>View Citizen</span></a></li>
        <li class="liste"><a href="report_citizen.php"><i class="fa fa-plus"></i> <span>Citizen Report(<?php echo $kog;?>)</span></a></li>
        
    
      
        <li class="card-header"><div class="c">REPORTS</div></li>
        
        <li class="liste"><a href="dis_report.php"><i class="fa fa-clock"></i> <span>
        disaster</span></a></li>
        
        <li class="liste"><a href="single_report.php"><i class="fa fa-clock"></i> <span>Single Citizen</span></a></li>
      
        <li class="liste"><a href="sect_all.php"><i class="fa fa-clock"></i> <span>Overal</span></a></li>
        
        
       
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>