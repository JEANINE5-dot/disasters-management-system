<?php include 'include/a_session.php';?>
<?php include 'include/header.php';

?>
<div class="wrapper">
<?php include 'include/a_nav.php';?>
<?php include 'include/a_navbar.php';?>

<div class="content-wrapper">
  <section class="content-header text-center">
    <p>Admin Update</p>
  </section>
  <section class="content">
    <div class="col-md-12">
      <?php
      if (isset($_POST["register"])){
          $username = $_POST["username"];
          $name=$_POST["name"];
          $password=$_POST["password"];
          $phone=$_POST["phone"];
          
        $add="UPDATE chief_sector SET ch_name='$name',ch_username='$username',ch_phone='$phone',ch_password='$password' WHERE ch_id='$admin_id'";

      
        $query=mysqli_query($db,$add);
            if ($query) {
              ?> 
                <div class="alert alert-success strover animated bounce col-md-12" id="aji">
                  <button class="close" data-dismiss="alert"></button>
                  <center><i>Successfuly Updated</i></center>
                </div>
              <?php
            }

      }
      if (isset($_POST['profile'])) {
        $profile=$_FILES['profile']['name'];
          $bphomove="../img/".$_FILES['profile']['name'];
          $add="UPDATE chief_sector SET ch_profile='$profile' WHERE ch_id='$admin_id'";
        $a=move_uploaded_file($_FILES['profile']['tmp_name'], $bphomove);
        $query=mysqli_query($db,$add);
            if ($query AND $a) {
              ?> 
                <div class="alert alert-success strover animated bounce col-md-12" id="aji">
                  <button class="close" data-dismiss="alert"></button>
                  <center><i>Profile Picture Successfuly Updated</i></center>
                </div>
              <?php
            }
      }
      $shae= "SELECT * FROM chief_sector WHERE ch_id= '$admin_id'";
  $dool= mysqli_query($db,$shae);
  $row= mysqli_fetch_array($dool);

      ?>
      <div class="row">
        
        
      </div>
      <div class="row">
        
          <div class="col-md-4 offset-md-4">
          <img src="../img/<?php echo $row['ch_profile']?>" id="photo" style="width: 300px;height: 180px;">
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 offset-md-4">
          <form method="post"enctype="multipart/form-data">
            <div class="form-row">
             <div class="form-group col-md-5">
            <input type="file" class="form-control" id="email" name="profile" value="<?php echo $row['ch_profile']?>">
            </div>
            <div class="col-md-6">
              <button type="submit" name="profile" id="register" class="btn btn-outline-dark btn-block"><i class="fa fa-paper-plane"></i> Update Profile</button>
            </div>
            </div>
          </form>
        </div>
        
       </div>
       <div class="row"> 
        <div class="col-md-8 offset-md-2">
        <form method="post" action="#" id="reg_form"enctype="multipart/form-data">
                  
                  
                  <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="name">Fullname</label>
                        <!-- <div class="input-group"> -->
                        <!-- <span class="input-group-addon"><i class="fa fa-user"></i></span> -->
                        <input type="text" class="form-control" id="name" name="name" placeholder=" Fullname" value="<?php echo $row['ch_name'];?>" required >
                        
                      <!-- </div> -->
                    </div>
                    <div class="form-group col-md-6">
                      <label for="inputAddress" >Email</label>
                      <!-- <div class="input-group"> -->
                      <!-- <span class="input-group-addon"><i class="fa fa-lock"></i></span> -->
                      <input type="text" class="form-control" id="email" name="username"  value="<?php echo $row['ch_username'];?>" required>
                    <!-- </div> -->
                  </div>
                    
                  </div>
                  <div class="form-row">
                  
                  
                   <div class="form-group col-md-6">
                        <label for="email" >Phone</label>
                        <!-- <div class="input-group"> -->
                        <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                        <input type="text" class="form-control" id="email" name="phone" placeholder="username" value="<?php echo $row['ch_phone'];?>" required>
                    <!--   </div> -->
                    </div>
                     <div class="form-group col-md-6">
                        <label for="email" >Password</label>
                        <!-- <div class="input-group"> -->
                        <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                        <input type="text" class="form-control" id="email" name="password"  value="<?php echo $row['ch_password'];?>" required>
                    <!--   </div> -->
                    </div>
                  </div> 
                  <button type="submit" name="register" id="register" class="btn btn-outline-dark btn-block"><i class="fa fa-paper-plane"></i> Update</button>
                </form>
      </div>
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>

</body>
</html>