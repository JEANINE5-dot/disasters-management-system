<?php

	$db=mysqli_connect("localhost","root","","survey");
	$idoo=$_GET['id'];
	$resultoo="DELETE department WHERE dep_id='$idoo'";
	mysqli_query($db,$resultoo);

	
?>