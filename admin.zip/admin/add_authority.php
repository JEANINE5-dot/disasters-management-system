<?php include 'include/session.php';
$cat="SELECT * FROM sector";
$cate=mysqli_query($db,$cat);
?>
<?php include 'include/header.php';?>
<div class="wrapper">
<?php include 'include/nav.php';?>
<?php include 'include/navbar.php';?>

<div class="content-wrapper">
  <section class="content-header text-center">
    <h2>Add Chief Sector</h2>
  </section>
  <section class="content">
    <div class="row" style="">
      <div class="col-md-12" id="mia">
        <div class="col-md-8 offset-md-2 text-dark"id="took">
            <?php
            $national_id = "";
            $umu_id = "";
            $phone = "";
            $password="";
            $username="";
            $fullname="";
            $date="";
            
            
          if(isset($_POST["register"])){ 
            $national_id = $_POST["national_id"];
            $sect_id = $_POST["sect_id"];
            $phone = $_POST["phone"];
            $fullname=$_POST["fullname"];
            $password=$_POST["password"];
            $username=$_POST["username"];
            $date=$_POST["date"];
            $dep_picture=$_FILES['profile']['name'];
            $bphomove="../img/".$_FILES['profile']['name'];

            $allowed_image_extension = array(
                          "png",
                          "jpg",
                          "jpeg"
                      );
                    $file_extension = pathinfo($_FILES["profile"]["name"], PATHINFO_EXTENSION);

            $selectm="SELECT * FROM chief_sector WHERE ch_nationalid='$national_id'";
            $c= mysqli_query($db,$selectm);
            $user= mysqli_num_rows($c);

            $cholo="SELECT * FROM chief_sector WHERE sect_id='$sect_id'";
            $choo= mysqli_query($db,$cholo);
            $umurenge= mysqli_num_rows($choo);
                    
               if (!in_array($file_extension, $allowed_image_extension)) {
                          ?>
                          <style type="text/css">
                             #profile{
                               color: #a94442;
                               background-color: #f2dede;
                               border-color: #a94442;
                             }
                           </style>
                           <div class="alert alert-danger animated shake col-md-12" id="aji">
                             <button class="close" data-dismiss="alert"></button>
                             <center><i>Only PNG and JPG are allowed in Profile Field!!!</i></center>
                           </div>
                          <?php
                           
                        } 
              elseif($user){
                ?>
                <style type="text/css">
                  #national_id{
                    color: #a94442;
                    background-color: #f2dede;
                    border-color: #a94442;
                  }
                </style> 
                       <div class="alert alert-danger animated shake col-md-12" id="sams1">
                        <button class="close" data-dismiss="alert"></button>
                        <center><i>This National id is already a chef of sector!!!</i></center>
                     </div>
                        <?php
              }
              elseif ($umurenge) {
                 ?>
                <style type="text/css">
                  #sector{
                    color: #a94442;
                    background-color: #f2dede;
                    border-color: #a94442;
                  }
                </style> 
                       <div class="alert alert-danger animated shake col-md-12" id="sams1">
                        <button class="close" data-dismiss="alert"></button>
                        <center><i>This Sector Chosen has already a chef of sector!!!</i></center>
                     </div>
                        <?php
              }
              
              else{
                $add="INSERT INTO  chief_sector(ch_name,ch_nationalid,ch_phone,ch_username,ch_password,sect_id,ch_date,ch_profile) VALUES ('$fullname','$national_id','$phone','$username','$password','$sect_id','$date','$dep_picture')";
                $a=move_uploaded_file($_FILES['profile']['tmp_name'], $bphomove);
                  $aln=mysqli_query($db,$add);
              if ($aln AND $a) {
                ?> 
                       <div class="alert alert-success strover animated bounce col-md-12" id="sams1">
                        <button class="close" data-dismiss="alert"></button>
                        <center><i>Successfuly Registred</i></center>
                     </div>
                        <?php
              }
              }
              
           }
           ?>
            <form method="post" action="#" id="reg_form"enctype="multipart/form-data">
                    
                    
                    <div class="form-row">
                      <div class="form-group col-md-6">
                          <label for="name">Fullname</label>
                          <!-- <div class="input-group"> -->
                          <!-- <span class="input-group-addon"><i class="fa fa-user"></i></span> -->
                          <input type="text" class="form-control" id="name" name="fullname" placeholder=" Fullname" value="<?php echo $fullname;?>" required >
                          
                        <!-- </div> -->
                      </div>
                      <div class="form-group col-md-6">
                          <label for="username" >National ID</label>
                          <!-- <div class="input-group"> -->
                         <!--  <span class="input-group-addon"><i class="fa fa-user"></i></span> -->
                          <input type="text" class="form-control" id="national_id" name="national_id" placeholder=" ID" value="<?php echo $national_id;?>" required>
                        <!-- </div> -->
                      </div>
                    </div>
                    <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="inputAddress" >Sector</label>
                        <select name="sect_id" id="sector"class="form-control selectpicker" required >
                        
                        <?php
                        while ($category=mysqli_fetch_array($cate)) {
                          ?>
                          <option value="<?php echo $category['sec_id'];?>"><?php echo $category['sector_name'];?></option>
                          <?php
                        }
                      ?>
                    </select>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="inputAddress" >Phone number</label>
                        <!-- <div class="input-group"> -->
                        <!-- <span class="input-group-addon"><i class="fa fa-lock"></i></span> -->
                        <input type="text" class="form-control" id="email" name="phone" placeholder="phone" value="<?php echo $phone;?>" required>
                      <!-- </div> -->
                    </div>
                     <div class="form-group col-md-4">
                        <label for="inputAddress" >Profile</label>
                        <!-- <div class="input-group"> -->
                        <!-- <span class="input-group-addon"><i class="fa fa-lock"></i></span> -->
                        <input type="file" class="form-control" id="email" name="profile" required>
                      <!-- </div> -->
                    </div>
                    </div>
                    <div class="form-row">
                      <div class="form-group col-md-4">
                          <label for="email" >Username</label>
                          <!-- <div class="input-group"> -->
                          <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                          <input type="text" class="form-control" id="email" name="username" placeholder="username" value="<?php echo $username;?>" required>
                      <!--   </div> -->
                      </div>
                      <div class="form-group col-md-4">
                          <label for="email" >Password</label>
                          <!-- <div class="input-group"> -->
                          <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                          <input type="text" class="form-control" id="email" name="password" placeholder="password" value="<?php echo $password;?>" required>
                      <!--   </div> -->
                      </div>
                      <div class="form-group col-md-4">
                        <label for="passwordb" >Date</label>
                       <input type="text" class="form-control" id="date" name="date" placeholder=" Date of starting job" value="<?php echo $date;?>" required>
                    </div>
                     
                    </div>
                   
                   <div class="form-group row">
                    <div class="col-md-12">
                    <button type="submit" name="register" id="register" class="btn btn-outline-success btn-block"><i class="fa fa-paper-plane"></i> Register</button>
                    </div>
                    </div>
                  </form>
        </div>
      </div>
    </div>
  </section>
</div>
    
  <?php include 'include/footer.php';?>

</body>
</html>